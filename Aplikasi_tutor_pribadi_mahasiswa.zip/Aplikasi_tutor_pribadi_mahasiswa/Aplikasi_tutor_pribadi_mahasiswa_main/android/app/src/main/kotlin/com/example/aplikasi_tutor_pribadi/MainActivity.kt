package com.example.aplikasi_tutor_pribadi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
